import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { CheckCircle2, Clock, Wrench, ListChecks } from "lucide-react";
import { toast } from "sonner";
import resisyncLogo from "@/assets/resisync-logo.png";

export function StaffDashboard() {
  const { user, profile } = useAuth();
  const [tasks, setTasks] = useState<any[]>([]);

  const fetchTasks = async () => {
    if (!user) return;
    const { data } = await supabase.from("complaints").select("*").eq("assigned_to", user.id).order("created_at", { ascending: false });
    if (data) setTasks(data);
  };

  useEffect(() => { fetchTasks(); }, [user]);

  const updateStatus = async (id: string, status: string) => {
    const updates: any = { status };
    if (status === "resolved") updates.resolved_at = new Date().toISOString();
    const { error } = await supabase.from("complaints").update(updates).eq("id", id);
    if (error) toast.error("Failed to update");
    else { toast.success("Status updated"); fetchTasks(); }
  };

  const stats = {
    total: tasks.length,
    assigned: tasks.filter((t) => t.status === "assigned").length,
    inProgress: tasks.filter((t) => t.status === "in_progress").length,
    resolved: tasks.filter((t) => t.status === "resolved" || t.status === "closed").length,
  };

  const statCards = [
    { title: "Total Assigned", value: stats.total, icon: ListChecks, gradient: "from-primary to-accent" },
    { title: "New Tasks", value: stats.assigned, icon: Clock, gradient: "from-[hsl(38,92%,50%)] to-[hsl(38,92%,60%)]" },
    { title: "In Progress", value: stats.inProgress, icon: Wrench, gradient: "from-accent to-teal" },
    { title: "Completed", value: stats.resolved, icon: CheckCircle2, gradient: "from-teal to-[hsl(160,84%,39%)]" },
  ];

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex items-center gap-3">
        <img src={resisyncLogo} alt="ResiSync" className="w-10 h-10 rounded-lg" />
        <div>
          <h1 className="text-2xl font-heading font-bold">Welcome to ResiSync</h1>
          <p className="text-muted-foreground text-sm">
            Hello, <span className="font-medium text-foreground">{profile?.full_name || "Staff"}</span> · Your assigned maintenance tasks
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {statCards.map((stat, i) => (
          <Card key={stat.title} className={`card-hover border-0 shadow-card overflow-hidden animate-fade-in-up animate-stagger-${i + 1}`}>
            <CardContent className="p-0">
              <div className="flex items-center justify-between p-5">
                <div>
                  <p className="text-sm text-muted-foreground font-medium">{stat.title}</p>
                  <p className="text-3xl font-heading font-bold mt-1">{stat.value}</p>
                </div>
                <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${stat.gradient} flex items-center justify-center shadow-md`}>
                  <stat.icon className="w-6 h-6 text-white" />
                </div>
              </div>
              <div className={`h-1 bg-gradient-to-r ${stat.gradient}`} />
            </CardContent>
          </Card>
        ))}
      </div>

      <Card className="shadow-card">
        <CardHeader>
          <CardTitle className="font-heading">Assigned Tasks</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {tasks.map((task) => (
            <div key={task.id} className="p-4 rounded-xl bg-secondary/50 hover:bg-secondary transition-all duration-200 space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="font-mono text-xs text-muted-foreground">{task.complaint_number}</span>
                    <Badge variant="outline" className="text-xs capitalize">{task.category}</Badge>
                    <Badge variant="outline" className="text-xs capitalize">{task.priority}</Badge>
                  </div>
                  <p className="font-semibold">{task.title}</p>
                  <p className="text-sm text-muted-foreground">{task.description}</p>
                  {task.wing && <p className="text-xs text-muted-foreground mt-1">Wing {task.wing}, Flat {task.flat_number}</p>}
                </div>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-sm text-muted-foreground">Update status:</span>
                <Select value={task.status} onValueChange={(val) => updateStatus(task.id, val)}>
                  <SelectTrigger className="w-40">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="assigned">Assigned</SelectItem>
                    <SelectItem value="in_progress">In Progress</SelectItem>
                    <SelectItem value="resolved">Resolved</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          ))}
          {tasks.length === 0 && <p className="text-muted-foreground text-center py-8">No tasks assigned yet</p>}
        </CardContent>
      </Card>
    </div>
  );
}
