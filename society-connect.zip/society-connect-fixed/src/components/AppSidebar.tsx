import {
  LayoutDashboard,
  MessageSquarePlus,
  ListChecks,
  Users,
  Calendar,
  Bell,
  BarChart3,
  LogOut,
  Megaphone,
  CreditCard,
  Wallet,
  Building2,
} from "lucide-react";
import { NavLink } from "@/components/NavLink";
import { useAuth } from "@/hooks/useAuth";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarFooter,
  useSidebar,
} from "@/components/ui/sidebar";
import { Button } from "@/components/ui/button";
import resisyncLogo from "@/assets/resisync-logo.png";

const navigationByRole = {
  resident: [
    { title: "Dashboard", url: "/dashboard", icon: LayoutDashboard },
    { title: "New Complaint", url: "/dashboard/complaints/new", icon: MessageSquarePlus },
    { title: "My Complaints", url: "/dashboard/complaints", icon: ListChecks },
    { title: "Payments", url: "/dashboard/payments", icon: CreditCard },
    { title: "Events", url: "/dashboard/events", icon: Calendar },
    { title: "Directory", url: "/dashboard/directory", icon: Users },
    { title: "Announcements", url: "/dashboard/announcements", icon: Megaphone },
    { title: "Notifications", url: "/dashboard/notifications", icon: Bell },
  ],
  admin: [
    { title: "Dashboard", url: "/dashboard", icon: LayoutDashboard },
    { title: "All Complaints", url: "/dashboard/complaints", icon: ListChecks },
    { title: "Manage Staff", url: "/dashboard/staff", icon: Users },
    { title: "Payments", url: "/dashboard/payments", icon: CreditCard },
    { title: "Funds", url: "/dashboard/funds", icon: Wallet },
    { title: "Events", url: "/dashboard/events", icon: Calendar },
    { title: "Announcements", url: "/dashboard/announcements", icon: Megaphone },
    { title: "Directory", url: "/dashboard/directory", icon: Building2 },
    { title: "Analytics", url: "/dashboard/analytics", icon: BarChart3 },
    { title: "Notifications", url: "/dashboard/notifications", icon: Bell },
  ],
  maintenance_staff: [
    { title: "Dashboard", url: "/dashboard", icon: LayoutDashboard },
    { title: "Assigned Tasks", url: "/dashboard/complaints", icon: ListChecks },
    { title: "Events", url: "/dashboard/events", icon: Calendar },
    { title: "Notifications", url: "/dashboard/notifications", icon: Bell },
  ],
};

export function AppSidebar() {
  const { role, signOut } = useAuth();
  const { state } = useSidebar();
  const collapsed = state === "collapsed";
  const items = navigationByRole[role || "resident"];

  return (
    <Sidebar className="border-r-0 gradient-sidebar" collapsible="icon">
      <div className="p-4 flex items-center gap-3">
        <img
          src={resisyncLogo}
          alt="ResiSync"
          className="w-9 h-9 rounded-lg object-contain flex-shrink-0"
        />
        {!collapsed && (
          <div className="flex flex-col">
            <span className="font-heading font-bold text-lg text-sidebar-primary-foreground leading-tight">ResiSync</span>
            <span className="text-[10px] text-sidebar-foreground/50 leading-tight">Smart Living</span>
          </div>
        )}
      </div>

      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel className="text-sidebar-foreground/40 uppercase text-[10px] tracking-widest font-semibold">
            {!collapsed && "Navigation"}
          </SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {items.map((item) => (
                <SidebarMenuItem key={item.title}>
                  <SidebarMenuButton asChild tooltip={item.title}>
                    <NavLink
                      to={item.url}
                      end={item.url === "/dashboard"}
                      className="text-sidebar-foreground/60 hover:text-sidebar-foreground hover:bg-sidebar-accent/80 transition-all duration-200 rounded-lg"
                      activeClassName="bg-sidebar-accent text-sidebar-primary font-medium shadow-sm"
                    >
                      <item.icon className="w-5 h-5" />
                      <span>{item.title}</span>
                    </NavLink>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>

      <SidebarFooter className="p-3">
        <Button
          variant="ghost"
          className="w-full justify-start text-sidebar-foreground/50 hover:text-destructive hover:bg-destructive/10 transition-all duration-200"
          onClick={signOut}
        >
          <LogOut className="w-5 h-5 mr-2" />
          {!collapsed && <span>Sign Out</span>}
        </Button>
      </SidebarFooter>
    </Sidebar>
  );
}
