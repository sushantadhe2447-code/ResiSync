-- Fix complaint number generation race condition.
-- Replace COUNT(*)+1 approach (which collides under concurrent inserts)
-- with a proper SEQUENCE that is atomically incremented.

CREATE SEQUENCE IF NOT EXISTS public.complaint_number_seq START 1;

-- Seed the sequence to the current complaint count so existing numbers are not reused
SELECT setval('public.complaint_number_seq', GREATEST((SELECT COUNT(*) FROM public.complaints), 1));

CREATE OR REPLACE FUNCTION public.generate_complaint_number()
RETURNS TRIGGER
LANGUAGE plpgsql
SET search_path = public
AS $$
BEGIN
  NEW.complaint_number := 'CMP-' || LPAD(nextval('public.complaint_number_seq')::TEXT, 5, '0');
  RETURN NEW;
END;
$$;
